﻿using System;
using System.Collections.Generic; 
using System.Collections;

namespace GenericAndNonGenericCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            //NonGenericCollection
            //A non generic collection allows you to dynamically create a list of data values. In non generic, you can have
            //data items of multiple datatypes.
            ArrayList Arr = new ArrayList();//ArrayList is a class that creates a dynamic array and allows to add datavalues of different datatypes
            Console.WriteLine("Data in Array:");
            Arr.Add("Siddharth");//Add() method is used to add data items to the array Arr
            Arr.Add("Patel");
            Arr.Add(20036);

            foreach (Object o in Arr)
            {
                Console.WriteLine(o);
            }

            //Similarly we have Stack:
            Stack stack = new Stack();

            Console.WriteLine("Data in Stack:");
            stack.Push("Siddharth");
            stack.Push("Patel");
            stack.Push(20036);
            //The items will be added using Push method in LIFO order

            foreach (Object o in stack)
            {
                Console.WriteLine(o);
            }

            //Pop() can be used to delete an item from top of stack:
            stack.Pop();
            Console.WriteLine("Data in stack after one pop operation:");
            foreach (Object o in stack)
            {
                Console.WriteLine(o);
            }

            //Similarly we have Queue
            Queue queue = new Queue();

            //Enqueue() is used to end data from the rear end of queue.
            queue.Enqueue("Siddharth");
            queue.Enqueue("Patel");
            queue.Enqueue(20036);

            Console.WriteLine("Data in Queue:");

            foreach (Object o in queue)
            {
                Console.WriteLine(o);
            }

            //Dequeue is used to delete an item from front of queue
            queue.Dequeue();

            Console.WriteLine("Queue after one dequeue operation: ");

            foreach (object o in queue)
            {
                Console.WriteLine(o);
            }

            //GENERIC COLLECTION
            //Here you can create a dynamic list but the data types of the items must be same.

            List<Int32> GenericIntegerList = new List<Int32>(); //A dynamic list of int type
            //You can individual values like this:
            GenericIntegerList.Add(20036);
            //Or add two or more items to the list at the same time by using AddRange() like this:
            GenericIntegerList.AddRange(new int[]{20, 30, 40, 50});

            Console.WriteLine();
            Console.WriteLine("Generic list of int type:");

            foreach (int v in GenericIntegerList)
            {
                Console.WriteLine(v);
            }

            //It is possible to create a Nongeneric list of items using the generic list List<>
            //by adding 'object' as the type in it.
            //Example: List<Object> NonGenUsingGen = new List<Object>();


















        }
    }
}